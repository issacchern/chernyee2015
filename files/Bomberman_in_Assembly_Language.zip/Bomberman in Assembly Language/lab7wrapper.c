extern int pin_connect_block_setup_for_uart0_GPIO_push_button(void);
extern int uart_init(void);
extern int lab7(void);	

int main()
{ 
   pin_connect_block_setup_for_uart0_GPIO_push_button();
   uart_init(); 
   lab7();
}
