#Description
This program manipulates pointers in linked list. It has several functions to manipulate the list which you can find in the #Usage section.

#Instruction
1. Download the project to your directory.
2. Use terminal to navigate to the directory, type "make" to build the project.
3. Type ./listmanip to run the program.

#Usage
- new listname = [list of ints]
- print listname
- remove listname [some int]
- sort listname
- merge listname1 listname2
- exit/quit/bye

#Examples 
- new mylist = 3 5 3 2 1
- print mylist
- sort mylist
- new mylist2 = 5 6 3 2 1
- sort mylist2
- merge mylist1 mylist2

#Author
- Chern Yee Chua
- chernyee@buffalo.edu