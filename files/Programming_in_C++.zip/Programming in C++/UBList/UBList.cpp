// ============================================================================ 
// UBList.cpp
// ~~~~~~~~~~
// author: Chern Yee Chua
// ============================================================================ 

#include <cstddef> // this header defines NULL
#include <iostream>
#include <stdexcept>
#include <sstream>

#include "UBList.h"

using namespace std; 

UBList::UBList(Node* h, size_t n) : head(h), numNodes(n)
{
}

UBList::UBList(const UBList& theOther)
{
    Node* cur;
    head = NULL;
    numNodes = 0;
    Node* ptr = theOther.head;
    while (ptr != NULL) {
        numNodes++;
        if (head == NULL) {
            cur = head = new Node(ptr->key);
        } else { 
            cur->next = new Node(ptr->key);
            cur = cur->next;
        }
        ptr = ptr->next;
    }
}

void UBList::swap(UBList& theOther)
{
    std::swap(numNodes, theOther.numNodes);
    std::swap(head, theOther.head);
}

UBList& UBList::operator=(const UBList& theOther)
{
    UBList temp(theOther); // deep copy
    swap(temp);
    return *this;
}

UBList::~UBList() 
{
    Node* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        delete temp;
    }
}  

void UBList::insert(int x)
{
    head = new Node(x, head);
    numNodes++;
}

string UBList::toString()
{
    ostringstream oss;
    oss << "[" << numNodes << " NODES] : ";
    Node* ptr = head;
    while (ptr != NULL) { 
        oss << ptr->key << " "; 
        ptr = ptr->next;    
    }
    return oss.str();
}

bool UBList::isSorted()
{
    for (Node* ptr = head; ptr != NULL && ptr->next != NULL; ptr = ptr->next)
        if (ptr->key > ptr->next->key) 
            return false;
    return true;
}

void UBList::merge(UBList& theOther)
{
    if (!this->isSorted() || !theOther.isSorted())
        throw runtime_error("Give give me sorted lists to merge");

    Node *temp = head;
    Node *otherHead = theOther.head;
    Node *tail = NULL;
    //Node *new_head = NULL;
    while(temp != NULL && otherHead != NULL){
        if(temp->key < otherHead->key){
            if(tail == NULL){
                head = temp;
                tail = temp;	
            }else{
                tail->next = temp;
                tail = temp;
            }
            temp = temp->next;
        }else{
            if(tail == NULL){
                head = otherHead;
                tail = otherHead;
            }else{
                tail->next = otherHead;
                tail = otherHead;
            }
            otherHead = otherHead->next;
        }
    }

    if(temp != NULL){
        if(tail == NULL){
            head = temp;
            tail = temp;
        }else{
            tail->next = temp;
        }		
    }

    if(otherHead != NULL){
        if(tail == NULL){
            head = otherHead;
            tail = otherHead;
        }else{
            tail->next = otherHead;
        }
    }     
    numNodes = numNodes + theOther.numNodes;
    theOther.head = NULL;
    theOther.numNodes = 0;
}

void UBList::remove(int x)
{
    Node* prev = NULL;
    Node* cur = head;
    while (cur != NULL) {
        if(cur->key == x){
            Node *temp = cur->next;
            if(prev == NULL){
                head = cur->next;
            }else{
                prev->next = temp;
            }
            delete cur;
            cur = temp;
            numNodes--;
        }else{
            prev = cur;
            cur = cur->next;
        }
    }   
}

void UBList::sort()
{
    if(numNodes < 2){
        return;
    }
    Node *fast = NULL, *slow = NULL;
    fast = head;
    slow = head;
    int first_size = 0;
    int second_size = 0;
    while(fast->next!= NULL && fast->next->next != NULL){
        fast = fast->next->next;
        slow = slow->next;
        first_size++;
    } 
    first_size++;
    second_size = numNodes - first_size;
    numNodes = first_size;
    Node *temp = slow->next;
    slow->next = NULL;
    UBList *second_list = new UBList(temp, second_size);  
    sort();    
    second_list->sort();
    merge(*second_list);
}

