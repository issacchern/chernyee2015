#Description
This program has two functions: validate() and display(). Validate() checks if the HTML expression is valid while display() prints the expression to the terminal. 

#Instruction
1. Download the project to your directory.
2. Use terminal to navigate to the directory, type "make" to build the project.
3. Type ./browser to run the program.

#Usage
- validate [expression] 
- display [expression] 
- exit/quit/bye

#Examples
- validate <red> This is red </red> but <blue> this is blue </blue>
- display <yellow> I see <bright> this is bright <blue> blue </blue> </bright> and now back to yellow </yellow>

#Author
- Chern Yee Chua
- chernyee@buffalo.edu