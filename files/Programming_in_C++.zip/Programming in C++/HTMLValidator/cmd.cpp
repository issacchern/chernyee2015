// ============================================================================
// cmd.cpp
// ~~~~~~~
// author: Chern Yee Chua
// ============================================================================

#include <iostream>
#include <sstream>
#include <stack>
#include <map>
#include "cmd.h"
#include "Lexer.h" 
#include "term_control.h"
#include "error_handling.h"

using namespace std;

Token tok; Lexer lexer;
stack<Token> mystack;

string display(const string& expression) 
{
	while(!mystack.empty()){
		mystack.pop();
	}
	
	string result = "";
	map<string, string> color_map;
	color_map["red"]   = "\033[31m";
	color_map["green"] = "\033[32m";
	color_map["blue"]  = "\033[34m";
	color_map["cyan"]  = "\033[36m";
	color_map["yellow"]  = "\033[33m";
	color_map["bright"]  = "\033[1m";
	color_map["dim"]  = "\033[2m";
	color_map["underline"]  = "\033[4m";
	
	color_map["/red"]   = "\033[0m";
	color_map["/green"] = "\033[0m";
	color_map["/blue"]  = "\033[0m";
	color_map["/cyan"]  = "\033[0m";
	color_map["/yellow"]  = "\033[0m";
	color_map["/bright"]  = "\033[0m";
	color_map["/dim"]  = "\033[0m";
	color_map["/underline"]  = "\033[0m";

	lexer.set_input(expression);
	
		//   + BLANK:  a consecutive sequence of space characters 
		//             which are ' ', '\r', '\n', and '\t'
		//   + IDENT:  a sequence of non-blank characters that does not start with <
		//   + TAG:    opening tag <sometag> or closing tag </sometag>
		//   + ENDTOK: marks the end of the input string
		//   + ERRTOK: means we are in an error state, for example, < without closing >

	while (lexer.has_more_token()) {

            tok = lexer.next_token();
            switch (tok.type) {
                case TAG:
                    if (tok.value[0] != '/'){
                    	if(tok.value == "red" || tok.value == "yellow" || tok.value == "green" || 
							tok.value == "blue" || tok.value == "cyan" || tok.value == "magenta" || tok.value == "bright" || tok.value == "underline" || tok.value == "dim"){								
                       			mystack.push(tok);
								string temp_string = tok.value;	
								result = result + color_map[temp_string];
								break;	
						}
						else{
							return "UNKNOWN TAG";							
						}
                    }
                        
                    else{
                    	if(tok.value == "/red" || tok.value == "/yellow" || tok.value == "/green" || 
							tok.value == "/blue" || tok.value == "/cyan" || tok.value == "/magenta" || tok.value == "/bright" || tok.value == "/underline" || tok.value == "/dim"){					                      		
								
								if(mystack.empty())
									return "EXPRESSION NOT WELL-FORMED";
								
								
								
								
								Token temp  = mystack.top();
								if(temp.value == tok.value.substr(1)){
									mystack.pop();		
									string temp_string = tok.value;								
									result = result + color_map[temp_string]; // <red> is <bright> if </bright> </red> 	
									if(!mystack.empty()){
										
										string temp_string2 = mystack.top().value;
										result = result + color_map[temp_string2];
									}
										
												
									break;				
								}
								
								else{
									return "EXPRESSION NOT WELL-FORMED!";
								}																																															
						}
						else{
							return "UNKNOWN TAG";
						}                	                    	
                    }
                    
                case IDENT:
                	result = result + tok.value;
                	break;
                
                case BLANK:
                	result = result + tok.value;
                	break;
                	
                case ERRTOK:
                    return "INVALID TOKEN";
                    break;

                default:
                    break;
            }
        }
        
        if(!mystack.empty())
        	return "EXPRESSION NOT WELL-FORMED!";
	
    return result;
}


string validate(const string& expression)
{
	while(!mystack.empty()){
		mystack.pop();
	}
	lexer.set_input(expression);
	while (lexer.has_more_token()) {
            tok = lexer.next_token();

            switch (tok.type) {
                case TAG:
                    if (tok.value[0] != '/'){
                    	if(tok.value == "red" || tok.value == "yellow" || tok.value == "green" || 
							tok.value == "blue" || tok.value == "cyan" || tok.value == "magenta" || tok.value == "bright" || tok.value == "underline" || tok.value == "dim"){
								mystack.push(tok);
								break;                   					
						}
						else{
							return "UNKNOWN TAG";							
						}
                    }
                        
                    else{
                    	if(tok.value == "/red" || tok.value == "/yellow" || tok.value == "/green" || 
							tok.value == "/blue" || tok.value == "/cyan" || tok.value == "/magenta" || tok.value == "/bright" || tok.value == "/underline" || tok.value == "/dim"){
							                      		
								if(mystack.empty())
									return "EXPRESSION NOT WELL-FORMED";
	
								
								Token temp  = mystack.top();
								if(temp.value == tok.value.substr(1)){
									mystack.pop();
									break;									
								}
								
								else{
									return "EXPRESSION NOT WELL-FORMED!";
								}										
						}
						else{
							return "UNKNOWN TAG";
						}                	                    	
                    }
                        
                case IDENT:
                	break;
                
                case BLANK:
                	break;        
                
                
                case ERRTOK:
                    return "INVALID TOKEN";
                    break;

                default:
                    break;
            }
        }
        
        if(!mystack.empty())
        	return "EXPRESSION NOT WELL-FORMED!";

    	return "VALID";
}
