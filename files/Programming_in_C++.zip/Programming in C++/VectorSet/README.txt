#Description
This program finds the number of integer pairs in both vector (vba) and set (sba) way.

#Instruction
1. Download the project to your directory.
2. Use terminal to navigate to the directory, type "make" to build the project.
3. Type ./edgecount to run the program.

#Usage
- vba filename.txt
- sba filename.txt
- exit/quit/bye

#Author
- Chern Yee Chua
- chernyee@buffalo.edu