// ============================================================================ 
// UBHeap.cpp
// ~~~~~~~~~~
// Chern Yee Chua
// - implement the UBHeap interface
// ============================================================================ 

#include <cstddef> // this header defines NULL
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <vector>
#include <unistd.h>
#include "UBHeap.h"

using namespace std; // BAD PRACTICE

vector<int> heap_;

UBHeap::UBHeap(const vector<int>& a)
{
    heap_ = a;
    heapify();	
}

UBHeap& UBHeap::operator=(const UBHeap& theOther)
{
    UBHeap temp; // deep copy
    heap_ = theOther.heap_;
    return *this; 
}

string UBHeap::toString()
{
    ostringstream oss;
    for(size_t i = 0; i < heap_.size();i++)
        oss << heap_[i] << " ";
    return oss.str();
}

void UBHeap::push(int x){
    heap_.push_back(x);
    floatUp(heap_.size() - 1);	
}

void UBHeap::pop(){
    if(empty() == 1)
    throw runtime_error("Heap is Empty");
    swap(heap_[0],heap_[heap_.size()-1]);
    heap_.pop_back();
    sink(0);
}

int UBHeap::top(){
    if(empty() == 1)
        throw runtime_error("Heap is Empty");
    int num = heap_[0];
    return num;
}

bool UBHeap::empty(){
    if(heap_.size() < 1) return true;
    else return false;
}


void UBHeap::heapify(){
    for(int i = heap_.size()/2; i>=0; i--) sink(i);
}

void UBHeap::sink(size_t i) {
    size_t left = 2*i + 1;
    if (left >= heap_.size()) return;
    size_t right = left + 1; // possibly >= n    
    size_t my_pick = (right >= heap_.size()) ?  left : 
        (heap_[right] > heap_[left]) ? right : left;
    if (heap_[i] < heap_[my_pick]) {
        swap(heap_[i], heap_[my_pick]);
        sink(my_pick);
    }
}

void UBHeap::floatUp(size_t i){
    int parentIndex, tmp;
    if(i != 0){
        parentIndex = (i-1)/2;
        if(heap_[parentIndex] < heap_[i]){
        tmp = heap_[parentIndex];
        heap_[parentIndex] = heap_[i];
        heap_[i] = tmp;
        floatUp(parentIndex);
        }
    }	
}


