#Description
This program demonstrates how heap works. It has several functions to manipulate the heap list which you can find in the #Usage section.

#Instruction
1. Download the project to your directory.
2. Use terminal to navigate to the directory, type "make" to build the project.
3. Type ./ubheap to run the program.

#Usage
- new listname = [list of ints]
- print listname
- push listname [some int]
- pop listname
- top listname
- exit/quit/bye

#Examples 
- new mylist = 3 5 3 2 1
- print mylist
- push mylist 3
- pop mylist
- top mylist

#Author
- Chern Yee Chua
- chernyee@buffalo.edu