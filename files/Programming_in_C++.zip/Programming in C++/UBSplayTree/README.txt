#Description
This program demonstrates how splay tree works. We will see how the tree is changed when inserting, removing or finding a key in the tree. 

#Instruction
1. Download the project to your directory.
2. Use terminal to navigate to the directory, type "make" to build the project.
3. Type ./splaydriver to run the program.

#Usage
- newtree
- print
- insert key
- remove key
- find key 
- exit/quit/bye

#Examples 
- newtree
- insert 10 20 30 40
- remove 20
- find 30

#Author
- Chern Yee Chua
- chernyee@buffalo.edu