import java.util.HashMap;

/* 
 *----------------------------------- Tiny PL ------------------------------------------|
 * 	Name: Chern Yee Chua ID: 50065317
 *  Name: Junlin Tang	 ID: 50050397
 *--------------------------------------------------------------------------------------*/

public class TinyPL {
	public static HashMap<Character, String> ST = new HashMap<Character, String>();
		
	public static void main(String args[]) {   
		System.out.println("Welcome. Use end to terminate");
		   Lexer.lex();   
		   
		   try{
			   new Program();		   
		   }
		   catch(Redeclaration s){
			   System.out.println(s);
		   }
		   catch(TypeMismatch s){
			   System.out.println(s);
		   }
		   catch(TypeUnknown s){
			   System.out.println(s);
		   }
			
			

	}
}

@SuppressWarnings("serial")
class Redeclaration extends Exception {
	public String message;

	public Redeclaration(String s) {
		super(s);
		message = s;
	}
}

@SuppressWarnings("serial")
class TypeUnknown extends Exception {
	public String message;

	public TypeUnknown(String s) {
		super(s);
		message = s;
	}
}

@SuppressWarnings("serial")
class TypeMismatch extends Exception {
	public String message;

	public TypeMismatch(String s) {
		super(s);
		message = s;
	}
}

class Program {
	 Decls decls;
	 Stmts stmts;
	 
	 public Program() throws Redeclaration, TypeMismatch, TypeUnknown{
		 if(Lexer.nextToken == Token.KEY_BEGIN){
			Lexer.lex();
			decls = new Decls();
			stmts = new Stmts();
			 if(Lexer.nextToken == Token.KEY_END){
				 System.exit(1);
			 } 		 		 
		 }
	 }
}

class Decls {
	Idlist idlist1, idlist2, idlist3;
	public Decls() throws Redeclaration, TypeUnknown{
		
		if(Lexer.nextToken == Token.KEY_INT || Lexer.nextToken == Token.KEY_REAL
				 || Lexer.nextToken == Token.KEY_BOOL){
			idlist1 = new Idlist();
			if(Lexer.nextToken == Token.SEMICOLON){
				Lexer.lex();
			}
		}
		if(Lexer.nextToken == Token.KEY_INT || Lexer.nextToken == Token.KEY_REAL
				 || Lexer.nextToken == Token.KEY_BOOL){
			idlist2 = new Idlist();
			if(Lexer.nextToken == Token.SEMICOLON){
				Lexer.lex();
			}
		}
		if(Lexer.nextToken == Token.KEY_INT || Lexer.nextToken == Token.KEY_REAL
				 || Lexer.nextToken == Token.KEY_BOOL){
			idlist3 = new Idlist();
			if(Lexer.nextToken == Token.SEMICOLON){
				Lexer.lex();
			}
		}
	}
}

class Idlist {
	Id_Lit id_lit;
	Idlist idlist;
	String type;
	public Idlist() throws Redeclaration, TypeUnknown{
		if(Lexer.nextToken == Token.KEY_INT)
			type = "int";
		else if(Lexer.nextToken == Token.KEY_REAL)
			type = "real";
		else if(Lexer.nextToken == Token.KEY_BOOL)
			type = "bool";
	
		Lexer.lex(); //consume "type" 
		 
		if(TinyPL.ST.get(Lexer.ident) == null){
			TinyPL.ST.put(Lexer.ident, type);
			id_lit = new Id_Lit();
			Lexer.lex(); // consume ID
			while(Lexer.nextToken == Token.COMMA){
				idlist = new Idlist(type); //pass in type to the constructor
			}
		}		 
		else{
			throw new Redeclaration(Lexer.ident + " has been declared before.");
		}
	 }
	
	public Idlist(String string) throws Redeclaration, TypeUnknown{
		Lexer.lex(); //consume ","
		type = string;
		if(TinyPL.ST.get(Lexer.ident) == null){
			TinyPL.ST.put(Lexer.ident, type);
			id_lit = new Id_Lit();
			Lexer.lex(); //consume ID
			while(Lexer.nextToken == Token.COMMA){
				idlist = new Idlist(type);
			}
		}
		else{
			throw new Redeclaration (Lexer.ident + " has been declared before.");
		}
		
	}

}

class Stmts {
	Stmts stmts;
	Stmt stmt;
	public Stmts() throws TypeMismatch, TypeUnknown{	
		
		if(Lexer.nextToken == Token.ID || Lexer.nextToken == Token.KEY_WHILE 
				|| Lexer.nextToken == Token.KEY_IF || Lexer.nextToken == Token.LEFT_BRACE ){
			
			stmt = new Stmt();
		}

		if(Lexer.nextToken == Token.ID || Lexer.nextToken == Token.KEY_WHILE 
				|| Lexer.nextToken == Token.KEY_IF || Lexer.nextToken == Token.LEFT_BRACE ){			
			
			stmts = new Stmts();			
		}
	
	}
	 
}

class Stmt {
	Assign assign;
	Cond cond;
	Loop loop;
	Cmpd cmpd;

	public Stmt() throws TypeMismatch, TypeUnknown{
		switch(Lexer.nextToken){
		case Token.ID:
			assign = new Assign();				
			break;
		case Token.KEY_WHILE:
			loop = new Loop();		
			break;
		case Token.KEY_IF:
			cond = new Cond();
			break;
		case Token.LEFT_BRACE:
			cmpd = new Cmpd();	
			break;
		}
	}
	 
} 

class Assign {
	Expr expr;
	String type;
	public Assign() throws TypeMismatch, TypeUnknown{ 
		if(TinyPL.ST.get(Lexer.ident) == null){
			throw new TypeUnknown(Lexer.ident + " is not declared.");
		}
		else{
			type = TinyPL.ST.get(Lexer.ident); // get the type of ID
			Lexer.lex(); //consume id				
			if(Lexer.nextToken == Token.ASSIGN_OP){
				Lexer.lex(); //consume "="
				expr = new Expr();
				if(expr.type == type){ // checking type of ID and assignment
					if(Lexer.nextToken == Token.SEMICOLON)
						Lexer.lex();
				}	
				else{
					throw new TypeMismatch( type + " type does not match with " + expr.type);
				}

			}
			
		}
	
	}
	 
}

class Cond  {
	Expr expr;
	Stmt stmt1, stmt2;
	public Cond() throws TypeMismatch, TypeUnknown{
		Lexer.lex(); //consume "if"
		expr = new Expr();		
		if(expr.type != "bool"){ // must have type of boolean expression
			throw new TypeMismatch("IF statement requires Boolean expression!");
		}
		else{
			stmt1 = new Stmt();
			if(Lexer.nextToken == Token.KEY_ELSE){
				Lexer.lex(); //consume "else"
				stmt2 = new Stmt();	
			}
		}
		
	} 
}

class Loop {
	Expr expr;
	Stmt stmt;
	public Loop() throws TypeMismatch, TypeUnknown{
		Lexer.lex(); //consume "while"
		expr = new Expr();
		if(expr.type != "bool"){
			throw new TypeMismatch("WHILE statement requires Boolean expression!");
		}
		else{
			stmt = new Stmt();
		}
		
	}
}

class Cmpd  { 
	Stmts stmts;
	public Cmpd() throws TypeMismatch, TypeUnknown{
		Lexer.lex(); //consume "{"
		stmts = new Stmts();
		if(Lexer.nextToken == Token.RIGHT_BRACE){
			Lexer.lex();
		}
	}
}

class Expr {  
	Term term;
	Expr expr;
	String type;
	public Expr() throws TypeMismatch, TypeUnknown{
		term = new Term();
		type = term.type;

		if(Lexer.nextToken == Token.ADD_OP || Lexer.nextToken == Token.SUB_OP
				|| Lexer.nextToken == Token.OR_OP){
			if(Lexer.nextToken == Token.ADD_OP){
				if(term.type == "bool"){
					throw new TypeMismatch("Boolean type is invalid for addition.");
				}
			}
			else if(Lexer.nextToken == Token.SUB_OP){
				if(term.type == "bool"){
					throw new TypeMismatch("Boolean type is invalid for subtraction.");
				}
			}
			else if(Lexer.nextToken == Token.OR_OP){
				if(term.type != "bool"){
					throw new TypeMismatch("OR Operation works on Boolean only.");
				}
			}
			Lexer.lex(); //consume "+" or "-" or "||"
			expr = new Expr(); 		
			if(term.type != expr.type){ // checking type matches
				throw new TypeMismatch(term.type + " doesn't match with " + expr.type);
			}
		}
	}
}

class Term {  
	Factor factor;
	Term term;
	String type;
	public Term() throws TypeMismatch, TypeUnknown{
		factor = new Factor();
		type = factor.type;
		
		if (Lexer.nextToken == Token.MULT_OP || Lexer.nextToken == Token.DIV_OP 
				|| Lexer.nextToken == Token.AND_OP){	
			
			if(Lexer.nextToken == Token.MULT_OP){
				if(factor.type == "bool"){
					throw new TypeMismatch("Boolean type is invalid for multiplication");
				}
			}
			else if(Lexer.nextToken == Token.DIV_OP){
				if(factor.type == "bool"){
					throw new TypeMismatch("Boolean type is invalid for division");
				}
				
			}
			else if(Lexer.nextToken == Token.AND_OP){
				if(factor.type != "bool"){
					throw new TypeMismatch("AND Operation works on Boolean only");
				}
			}
			Lexer.lex(); // consume "*" or "/" or "&&"
			term = new Term();	
			if(factor.type != term.type) // checking type matches
				throw new TypeMismatch(factor.type + " doesn't match with " + term.type);
		}		
	}
}


class Factor {  
	Literal literal;
	Factor factor;
	Expr expr,expr2;
	int i;
	double r;
	String type;
	String op = "";
	public Factor() throws TypeMismatch, TypeUnknown{
		switch(Lexer.nextToken){
		 case Token.ID:
			 literal = new Id_Lit();
			 type = Id_Lit.type;
			 Lexer.lex();		 
			 
			 break;
		case Token.NEG_OP:
			Lexer.lex();
			factor = new Factor();
			type = factor.type;
			if(type != "bool"){
				throw new TypeMismatch("Negation only works on boolean expression! ");
			}
			break;
		case Token.LEFT_PAREN:
			Lexer.lex();
			expr = new Expr();
			type = expr.type;
			
			 if(Lexer.nextToken == Token.RIGHT_PAREN){
				 Lexer.lex();
			 }
						 
			 else if(Lexer.nextToken == Token.LE_OP
					 ||Lexer.nextToken == Token.GE_OP
					 ||Lexer.nextToken == Token.EQ_OP
					 ||Lexer.nextToken == Token.NE_OP
					 ||Lexer.nextToken == Token.LT_OP
					 ||Lexer.nextToken == Token.GT_OP){
				 
				 Lexer.lex();
				 expr2 = new Expr();
				 if(type == expr2.type){ // checking expression type matches
					 type = "bool"; // Factor type should be boolean after the type 
					 				// checking is valid
					 if(Lexer.nextToken == Token.RIGHT_PAREN){
						 Lexer.lex(); // consume ")"
					 }
				 }
				 else{
					 throw new TypeMismatch(expr.type + " doesn't match with " + expr2.type);
				 }
			 }
			 
			break;	
		 case Token.INT_LIT:			 
			 literal = new Int_Lit();
			 i = Int_Lit.i;
			 type = Int_Lit.type;
			 Lexer.lex();
			 break;
		 case Token.REAL_LIT:
			 literal = new Real_Lit();
			 r = Real_Lit.r;
			 type = Real_Lit.type;
			 Lexer.lex();
			 break;
		 case Token.FALSE_LIT:
			 literal = new Bool_Lit();
			 type = Bool_Lit.type;
			 Lexer.lex();
			 break;
		 case Token.TRUE_LIT:
			 literal = new Bool_Lit();
			 type = Bool_Lit.type;
			 Lexer.lex();
			 break;
		default:
			break;
		}	
	}
}

class Literal {
	Int_Lit int_lit;
	Real_Lit real_lit;
	Bool_Lit bool_lit;
	Id_Lit id_lit;
}

class Int_Lit extends Literal {
	static int i;
	static String type;
	public Int_Lit(){
		type = "int";
		i = Lexer.intValue;
	}
}

class Real_Lit extends Literal {
	static double r;
	static String type;
	public Real_Lit(){	
		type = "real";
		r = Lexer.realValue;
	}
}

class Bool_Lit extends Literal {
	boolean bool;
	static String type;
	 public Bool_Lit(){
		 type = "bool";
	 
		 if(Lexer.nextToken == Token.TRUE_LIT){
			 bool = true;
		 }
		 else{
			 bool = false;
		 }
	 
	 }
}

class Id_Lit extends Literal {
	char id;
	static String type;
	public Id_Lit() throws TypeUnknown{
		id = Lexer.ident;
		if(TinyPL.ST.get(id) == null){
			throw new TypeUnknown(id + " is not declared.");
		}
		else{
			type = TinyPL.ST.get(id);
		}
	}

}