#Description
This program creates a tiny programming language which follows Chomsky Notation as well as Extended Backus-Naur Form. We use JIVE (a plugin for Eclipse) to debug the program and generate the object diagram tree according to the user input. Check TestCases folder for snapshots and testcases.

#Instruction
1. Download and install JIVE - http://www.cse.buffalo.edu/jive/download.html
2. In Debug Configuration, click JIVE tab and select Enable debugging with JIVE and click Debug.
3. Switch to Debug mode, click Window > Show View > Other... > JIVE to open the object diagram view.
3. Copy and paste the code into system console, the JIVE will generate the object diagram view based on your code. 

#Author
- Chern Yee Chua
- chernyee@buffalo.edu