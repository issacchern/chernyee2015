package memory;

import java.util.Collections;
import java.util.Random;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Game implements Runnable {

	@Override
	public void run() {

		Random rand = new Random();
		JFrame frame = new JFrame("Memory Game");
		JPanel _panel = new JPanel();
		_panel.setLayout(new GridLayout(4, 4));
		frame.add(_panel);

		ArrayList<String> up = new ArrayList<String>();
		for (int i = 1; i < 4; i++) {
			up.add("Images/B0" + i + ".png");
		}

		ArrayList<String> down = new ArrayList<String>();
		for (int i = 1; i < 10; i++) {
			down.add("Images/F0" + i + ".png");
		}
		for (int i = 0; i < 10; i++) {
			down.add("Images/F1" + i + ".png");
		}
		for (int i = 0; i < 3; i++) {
			down.add("Images/F2" + i + ".png");
		}

		ArrayList<ImageIcon> uppic = new ArrayList<ImageIcon>();
		for (int i = 0; i < 3; i++) {
			uppic.add(new ImageIcon(up.get(i)));
			Collections.shuffle(uppic);
		}

		ArrayList<ImageIcon> downpic = new ArrayList<ImageIcon>();

		for (int i = 0; i < 22; i++) {
			downpic.add(new ImageIcon(down.get(i)));
			Collections.shuffle(downpic);
		}

		int n = rand.nextInt(3);
		ArrayList<JLabel> label = new ArrayList<JLabel>(16);

		for (int i = 0; i < 16; i++) {
			label.add(new JLabel());
			label.get(i).setIcon(uppic.get(n));
		}

		ArrayList<ImageIcon> pair = new ArrayList<ImageIcon>();
		for (int i = 0; i < 8; i++) {
			pair.add(downpic.get(i));
			pair.add(downpic.get(i));
		}

		Collections.shuffle(pair);

		for (int i = 0; i < label.size(); i++) {
			label.get(i).addMouseListener(
					new LabelListener(uppic, downpic, label, _panel, n, pair));
			_panel.add(label.get(i));
		}

		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Game());
	}
}
