package memory;

import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class LabelListener implements MouseListener {

	private static ArrayList<ImageIcon> _uppic;
	private static ArrayList<ImageIcon> _downpic;
	private static ArrayList<JLabel> _label;
	@SuppressWarnings("unused")
	private static JPanel _panel;
	private static int _n;
	@SuppressWarnings("unused")
	private static ArrayList<JLabel> j;
	private static ArrayList<ImageIcon> _pair;
	private static boolean begin = true;
	private static long start;
	private static long end;

	public LabelListener(ArrayList<ImageIcon> uppic,
			ArrayList<ImageIcon> downpic, ArrayList<JLabel> label,
			JPanel panel, int n, ArrayList<ImageIcon> pair) {
		_uppic = uppic;
		_downpic = downpic;
		_label = label;
		_panel = panel;
		_n = n;
		_pair = pair;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		new Card(_uppic, _downpic, _label);
		boolean alldown = Card.alldown();
		if (begin) {
			start = System.currentTimeMillis();
			begin = false;
		}

		ArrayList<JLabel> match = new ArrayList<JLabel>();

		if (alldown == true) {
			if (begin = false) {
				long start = System.currentTimeMillis();
			}

			for (int i = 0; i < _label.size(); i++) {
				if (e.getSource() == _label.get(i)) {
					if (_uppic.contains(_label.get(i).getIcon())) {
						_label.get(i).setIcon(_pair.get(i));
					}
				}
			}
			return;
		}

		boolean one = Card.oneselected();

		if (one == true) {
			for (int i = 0; i < _label.size(); i++)
				if (e.getSource() == _label.get(i)) {
					if (_uppic.contains(_label.get(i).getIcon())) {
						_label.get(i).setIcon(_pair.get(i));
					}
				}

			for (int i = 0; i < _label.size(); i++) {
				if (_downpic.contains(_label.get(i).getIcon())) {
					match.add(_label.get(i));
				}
			}
			return;
		}
		boolean two = Card.twoselected();
		if (two == true) {

			for (int i = 0; i < _label.size(); i++) {
				if (_downpic.contains(_label.get(i).getIcon())) {
					match.add(_label.get(i));
				}
			}
			alldown = true;
			two = false;
			for (int i = 0; i < _label.size(); i++) {

				if (Card.match(match.get(0), match.get(1)) == true) {
					match.get(0).setIcon(null);
					match.get(1).setIcon(null);
					if (Card.isEmpty() == true) {
						end = System.currentTimeMillis();
						long time = (end - start) / 1000;
						System.out.println("Time you  use:" + "   " + time
								+ "  " + "seconds");
					}
					return;
				} else {
					match.get(0).setIcon(_uppic.get(_n));
					match.get(1).setIcon(_uppic.get(_n));
					return;
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}