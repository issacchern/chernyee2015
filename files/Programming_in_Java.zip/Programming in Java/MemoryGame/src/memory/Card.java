package memory;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.util.ArrayList;

public class Card {

	private static ArrayList<ImageIcon> _uppic;
	private static ArrayList<ImageIcon> _downpic;
	private static ArrayList<JLabel> _label;

	public Card(ArrayList<ImageIcon> uppic, ArrayList<ImageIcon> downpic,
			ArrayList<JLabel> label) {

		_uppic = uppic;
		_downpic = downpic;
		_label = label;
	}

	public static boolean alldown() {
		boolean zero = false;
		int t = 0;
		for (int i = 0; i < _label.size(); i++)
			if (_downpic.contains(_label.get(i).getIcon())) {
				t = t + 1;
			}
		if (t == 0) {
			zero = true;
		}
		return zero;
	}

	public static boolean oneselected() {
		boolean one = false;
		int t = 0;
		for (int i = 0; i < _label.size(); i++)
			if (_downpic.contains(_label.get(i).getIcon())) {
				t = t + 1;
			}
		if (t == 1) {
			one = true;
		}
		return one;
	}

	public static boolean twoselected() {
		boolean two = false;
		int t = 0;
		for (int i = 0; i < _label.size(); i++)
			if (_downpic.contains(_label.get(i).getIcon())) {
				t = t + 1;
			}
		if (t == 2) {
			two = true;
		}

		if (Card.oneselected() || Card.alldown() == true) {
			two = false;
		}
		return two;
	}

	public static boolean match(JLabel a, JLabel b) {
		boolean c = false;
		if (a.getIcon().toString() == b.getIcon().toString()) {
			c = true;
		}
		return c;
	}

	public static boolean isEmpty() {
		boolean isEmpty = false;
		int t = 0;
		for (int i = 0; i < _label.size(); i++) {
			if (_label.get(i).getIcon() == null) {
				t = t + 1;
			}
		}
		if (t == 16) {
			isEmpty = true;
		}
		return isEmpty;
	}

}
