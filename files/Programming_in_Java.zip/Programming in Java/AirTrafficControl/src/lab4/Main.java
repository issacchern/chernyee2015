package lab4;


import java.util.ArrayList;
import java.util.InputMismatchException;

import java.util.List;

import javax.swing.JOptionPane;

import lab4.Aircraft;

public class Main {
	
	private static List<Aircraft> aircraftList = new ArrayList<Aircraft>();
	private static void displaySingleAircraft(boolean displayAll, String indexToDisplay, Aircraft aircraft){

        if (displayAll){
        	 JOptionPane.showMessageDialog(null, 
        			 "Aircraft " + indexToDisplay +
        			 "\nName: " + aircraft.getName() +
        			 "\nType: " + aircraft.getType() +
        			 "\nAltitude: " + aircraft.getAltitude() + " ft." +
        			 "\nSpeed: " + aircraft.getSpeed() + " mph"
        			 ); 
        	
        }
        else{
        	JOptionPane.showMessageDialog(null, "Aircraft '" + aircraft.getName() + "' has been removed from the list!");
        }
    }
	
	public static void main (String[] args) throws Exception, InputMismatchException, NumberFormatException{
	
		try{

			
			String cmd = "Start";
			String aircraftName = "";
			String aircraftType = "";
			int altitude = 0;
			int speed = 0;
			 
			 while (cmd.compareToIgnoreCase("quit") != 0 ){
				 cmd = JOptionPane.showInputDialog(null, "************** Menu Options *************" +
						"\n'enter' - Entering Aircraft" + "\n'leave' - Leaving Aircraft" + 
						"\n'show' - Show Single Aircraft" + "\n'display' - Display All Aircraft" +
						"\n'quit' - Quit the Program" + "\nPlease input a command: "); 
				 if (cmd.compareToIgnoreCase("enter") == 0){ 
					 boolean continueInput0 = true;
					 do{
						 aircraftName = JOptionPane.showInputDialog(null, "Please enter an aircraft name: ");

					 
						 if(aircraftName.length()>0){
							 JOptionPane.showMessageDialog(null, "Input '" + aircraftName + "' has been stored." );
							 continueInput0 = false;

						 }
						 else{
							 JOptionPane.showMessageDialog(null, "Name cannot be empty" );

						 }
					 } while( continueInput0);

					 
					 boolean continueInput = true;
					 do{
						 try{
							 aircraftType = JOptionPane.showInputDialog(null, "************** Type Options *************" +
									 "\na. Wide-body airliner" + "\nb. Regional airliner" +
									 "\nc. Private plane" + "\nd. Military" + 
									 "\ne. Cargo Only" + "\nf. Unknown" +
									 "\nPlease enter an aircraft type: ");
						
							 if(aircraftType.equals("a")){
								 aircraftType = "Wide-body airliner";
								 JOptionPane.showMessageDialog(null, "Input 'Wide-body airliner' has been stored." );
								 continueInput = false;
							 }
							 else if(aircraftType.equals("b")){
								 aircraftType = "Regional airliner";
								 JOptionPane.showMessageDialog(null, "Input 'Regional airliner' has been stored." );
								 continueInput = false;
							 }
							 else if(aircraftType.equals("c")){
								 aircraftType = "Private plane";
								 JOptionPane.showMessageDialog(null, "Input 'Private plane' has been stored." );
								 continueInput = false;
							 }
							 else if(aircraftType.equals("d")){
								 aircraftType = "Military";
								 JOptionPane.showMessageDialog(null, "Input 'Military' has been stored." );
								 continueInput = false;
							 }
							 else if(aircraftType.equals("e")){
								 aircraftType = "Cargo only";
								 JOptionPane.showMessageDialog(null, "Input 'Cargo Only' has been stored." );
								 continueInput = false;
							 }
							 else if(aircraftType.equals("f")){
								 aircraftType = "Unknown";
								 JOptionPane.showMessageDialog(null, "Input 'Unknown' has been stored." );
								 continueInput = false;
							 }
							 else{
								 throw new InputMismatchException();
								 
							 }
						 }
						 catch(InputMismatchException ex){
							 JOptionPane.showMessageDialog(null, "Input mismatch. Please try again." );
						 }
							 
						 }while(continueInput);
					 	
					boolean continueInput2 = true;
					 do{
						 try{
							 String aircraftAltitude = JOptionPane.showInputDialog(null, "Please enter the aircraft altitude (ft.): ");
							 altitude = Integer.parseInt(aircraftAltitude);
							 do{
								 if(aircraftAltitude.contains("-")){
		                                JOptionPane.showMessageDialog(null, "A positive Integer is required.");
		                                try{
		                                	aircraftAltitude = JOptionPane.showInputDialog(null, "Please enter the aircraft altitude (ft.): ");
		                                    altitude = Integer.parseInt(aircraftAltitude);
		                                }
		                                catch(NumberFormatException ex){
		                                    JOptionPane.showMessageDialog(null, "Invalid input, press ok to continue.");
		                                }
								 }
							 }while(aircraftAltitude.contains("-") );
							 altitude = Integer.parseInt(aircraftAltitude);
							 
							 JOptionPane.showMessageDialog(null, "Input '" + aircraftAltitude + "' has been stored." );
							 continueInput2 = false;
							 
						 }
						 catch(NumberFormatException ex){
							 JOptionPane.showMessageDialog(null, "Invalid input, press ok to continue." );
						 }
					 }while(continueInput2);
					 
					 boolean continueInput3 = true;
					 do{
						 try{
							 String aircraftSpeed = JOptionPane.showInputDialog(null, "Please enter the aircraft speed (mph): ");
							 speed = Integer.parseInt(aircraftSpeed);
							 do{
								 if(aircraftSpeed.contains("-")){
		                                JOptionPane.showMessageDialog(null, "A positive Integer is required.");
		                                try{
		                                	aircraftSpeed = JOptionPane.showInputDialog(null, "Please enter the aircraft speed (ft.): ");
		                                	speed = Integer.parseInt(aircraftSpeed);
		                                }
		                                catch(NumberFormatException ex){
		                                    JOptionPane.showMessageDialog(null, "Invalid input, press ok to continue.");
		                                }
								 }

							 }while(aircraftSpeed.contains("-") );
							 speed = Integer.parseInt(aircraftSpeed);
							 JOptionPane.showMessageDialog(null, "Input '" + aircraftSpeed + "' has been stored." );
							 continueInput3 = false;
						 }
						 catch(NumberFormatException ex){
							 JOptionPane.showMessageDialog(null, "Invalid input, press ok to continue." );
						 }
					 }while(continueInput3);

					 JOptionPane.showMessageDialog(null, "This is the information below: " + 
							 "\nAircraft name: " + aircraftName + 
							 "\nAircraft type: " + aircraftType +
							 "\nAircraft altitude: " + altitude + " ft." +
							 "\nAircraft speed: " + speed + " mph" 
							 );
					 
					 Aircraft newAircraft = new Aircraft(aircraftName, aircraftType, altitude, speed);			 
					 aircraftList.add(newAircraft);
					 
				 }
					 
				 if (cmd.compareToIgnoreCase("leave") == 0){
					 int aircraftIndexInList;
					 final int AIRCRAFT_NOT_FOUND = -1;
					 aircraftName = JOptionPane.showInputDialog(null, "Please enter an aircraft name: ");
					 Aircraft searchAircraft = new Aircraft(aircraftName, "", 0, 0);
					 
					 aircraftIndexInList = aircraftList.indexOf(searchAircraft);
				       
				        if (aircraftIndexInList == AIRCRAFT_NOT_FOUND){
				        	JOptionPane.showMessageDialog(null, "Aircraft: " + searchAircraft +
				        			" is not found in list!");
				        }
				        else{
				            searchAircraft = aircraftList.get(aircraftIndexInList);         
				            aircraftList.remove(aircraftIndexInList);        
				            displaySingleAircraft(false, "", searchAircraft);
				        }	 
				 }
				 
				 if (cmd.compareToIgnoreCase("show") == 0){
					 final int AIRCRAFT_NOT_FOUND = -1;
				     int aircraftIndexInList;
					 aircraftName = JOptionPane.showInputDialog(null, "Please enter an aircraft name: ");
					 
					 Aircraft searchAircraft = new Aircraft(aircraftName);
					
				     aircraftIndexInList = aircraftList.indexOf(searchAircraft);

					 if(aircraftIndexInList == AIRCRAFT_NOT_FOUND){
				        	JOptionPane.showMessageDialog(null, "Aircraft: " + searchAircraft.getName() +
				        			" is not found in list!");		
					 }
					 else{
						 searchAircraft = aircraftList.get(aircraftIndexInList);           
				         displaySingleAircraft(true, "", searchAircraft);
				         }
				 }
				 
				 if (cmd.compareToIgnoreCase("display") == 0){

					 int numberOfAircraftOnList;
					 numberOfAircraftOnList = aircraftList.size(); 
				     for(int aircraftIndex = 0; aircraftIndex < numberOfAircraftOnList; aircraftIndex++){
				    	 displaySingleAircraft(true, "Index: " + aircraftIndex, aircraftList.get(aircraftIndex));
				        }	
				 }
				 if (cmd.compareToIgnoreCase("quit") == 0){
					 JOptionPane.showMessageDialog(null, "All the aircrafts have been removed. Program is closing now.");
				        }
				 
				 if (cmd.compareToIgnoreCase("enter") != 0 &&
						 cmd.compareToIgnoreCase("leave") != 0 &&
						 cmd.compareToIgnoreCase("show") != 0 &&
						 cmd.compareToIgnoreCase("display") != 0 &&
					 cmd.compareToIgnoreCase("quit") != 0 ){
					 JOptionPane.showMessageDialog(null, "Invalid command.");

				 }			 
			 }

		} catch(Exception e){
			
		}
	}
}
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
		 
		
		
		
		
		
	