package lab4;

public class Aircraft extends Object {

	public final String DEFAULT_NAME = "U566";
	public final static String DEFAULT_TYPE = "Unknown";
	public final static int DEFAULT_ALTITUDE = 10;
	public final static int DEFAULT_SPEED = 500;

	private String name;
	private String type;
	private int altitude;
	private int speed;

	public Aircraft() {
		this.name = DEFAULT_NAME;
		this.type = DEFAULT_TYPE;
		this.altitude = DEFAULT_ALTITUDE;
		this.speed = DEFAULT_SPEED;
	}

	public Aircraft(String name) {
		this.name = name;
		this.type = DEFAULT_TYPE;
		this.altitude = DEFAULT_ALTITUDE;
		this.speed = DEFAULT_SPEED;
	}

	public Aircraft(String name, String type, int altitude, int speed) {
		this.name = name;
		this.type = type;
		this.altitude = altitude;
		this.speed = speed;
	}

	public String getName() {
		return this.name;
	}

	public String getType() {
		return this.type;
	}

	public int getAltitude() {
		return this.altitude;
	}

	public int getSpeed() {
		return this.speed;
	}

	@Override
	public String toString() {
		return "Aircraft name: " + this.getName() + " Type: " + this.getType()
				+ " Altitude: " + this.getAltitude() + " Speed: "
				+ this.getSpeed();
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setAltitude(int altitude) {
		this.altitude = altitude;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	@Override
    public boolean equals(Object otherObject){
        Aircraft otherAircraft;
        boolean aircraftMatch = false;  
        otherAircraft = (Aircraft)otherObject;
        if (this.name.equals(otherAircraft.getName()))
            aircraftMatch = true;    
        return aircraftMatch;
    }
}