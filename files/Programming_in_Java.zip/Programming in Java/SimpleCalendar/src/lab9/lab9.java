package lab9;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.InputMismatchException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class lab9 {
	private static int month = 1;
	private static JPanel datePanel;
    private static ArrayList<String> day;
	private static ArrayList<JLabel> dateLabel;
    private static ArrayList<String> monthList ;
    private static ArrayList<LabelListener> listeners;
    private static ArrayList<ArrayList<LabelListener> > listenerList;

    public static void main(String[] args) {
    	lab9.run();
    }
        
    public static void run(){
    	JFrame frame = new JFrame("Calendar");
    	frame.setLocation(450, 250);
    	frame.setTitle("Calendar");
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setVisible(true);
    	
    	monthList = new ArrayList<String>();
    	monthList.add("January  2013");
    	monthList.add("February  2013");
    	monthList.add("March  2013");
    	monthList.add("April  2013");
    	monthList.add("May  2013");
    	monthList.add("June  2013");
    	monthList.add("July  2013");
    	monthList.add("August  2013");
    	monthList.add("September  2013");
    	monthList.add("October  2013");
    	monthList.add("November  2013");
    	monthList.add("December  2013");
    	
    	day = new ArrayList<String>();
    	day.add("Sunday");
    	day.add("Monday");
    	day.add("Tuesday");
    	day.add("Wednesday");
    	day.add("Thursday");
    	day.add("Friday");
    	day.add("Saturday");
    	
    	JLabel monthLabel = new JLabel(monthList.get(0)); 
    	JPanel monthPanel = new JPanel(new FlowLayout()); 
    	monthPanel.add(monthLabel);
    	
    	JPanel Panel = new JPanel();        
    	Panel.setLayout(new BorderLayout());
    	
    	dateLabel = new ArrayList<JLabel>();
    	datePanel = new JPanel(new GridLayout(7,7,5,5)); 
    	
    	for(int i = 0; i < 7; i ++ ){
    		JLabel labeli =   new JLabel(day.get(i));
    		datePanel.add(labeli);
    	}
    	Panel.add("North", monthPanel);

    	
    	for(int i = 0; i < 42 ; i++){
    		JLabel label = new JLabel();
    		label.setBackground(Color.WHITE);
    		label.setOpaque(true);
    		dateLabel.add(label);
    		datePanel.add(dateLabel.get(i));
    	}
    	listenerList = new ArrayList<ArrayList<LabelListener> >();

    	for(int i = 0; i < 12 ; i++){
    		ArrayList<LabelListener>	arrayListener = new ArrayList<LabelListener> ();
    		for(int a = 0; a < 42 ; a++){
    			LabelListener s =   new LabelListener(dateLabel);
    			arrayListener.add(s);
    		}
    		listenerList.add(arrayListener);
    	}
    	getDatepanel(1);
    	Panel.add("Center", datePanel);
    	JPanel buttonPanel = new JPanel();        
    	JButton prior =  new JButton( "Prior");
    	JButton next = new JButton( "Next" );
    	prior.addMouseListener(new ButtonListener(monthLabel, monthList,prior,next, month, dateLabel,listeners,listenerList));
    	next.addMouseListener(new ButtonListener(monthLabel, monthList,prior,next, month , dateLabel, listeners, listenerList));
    	buttonPanel.setLayout(new FlowLayout());
    	buttonPanel.add(prior);
    	buttonPanel.add(next);
    	Panel.add("South", buttonPanel);
    	frame.add(Panel);
    	frame.pack();
     }
    
    public static void getDatepanel(int i){
    	switch(i){
    	case 1: arrangeDatepanel(1,2,9); break;
    	case 2: arrangeDatepanel(2,5,9); break;
    	case 3: arrangeDatepanel(3,5,6); break;
    	case 4: arrangeDatepanel(4,1,11); break;
        case 5: arrangeDatepanel(5,3,8); break; 
        case 6: arrangeDatepanel(6,6,6); break;
        case 7: arrangeDatepanel(7,1,10); break; 
        case 8: arrangeDatepanel(8,4,7); break; 
        case 9: arrangeDatepanel(9,7,5); break; 
        case 10: arrangeDatepanel(10,2,9); break; 
        case 11: arrangeDatepanel(11,5,7); break;
        case 12: arrangeDatepanel(12,7,4); break;
    	}
    }

    public static void arrangeDatepanel(int monthX, int start , int end ){
     	for(int i = 0; i < 42; i ++ ){
         	dateLabel.get(i).addMouseListener(listenerList.get(monthX - 1).get(i));
         	}

     	for(int a = 0; a < start; a ++ ){
         	dateLabel.get(a).setText("");
         	dateLabel.get(a).removeMouseListener(listenerList.get(monthX - 1).get(a));
         	}
     	
     	for(int c = 0 ; c < end   ; c ++ ){
     		dateLabel.get(42 - end +  c ).setText("");
         	dateLabel.get(42 - end +  c ).removeMouseListener(listenerList.get(monthX - 1).get(42 - end +  c ));
     	}
     	
     	for(int b = start; b< 42 - end ; b ++ ){
     		dateLabel.get(b).setText(Integer.toString(b-start + 1));
         	dateLabel.get(b).setForeground(Color.BLUE);
     	}
      }
    
    public static void removeListener(int previous){
    	for(int i = 0; i < 42 ; i++){
    		dateLabel.get(i).removeMouseListener(listenerList.get(previous  - 1).get(i));
     	    } 
    }
}

class ButtonListener implements MouseListener  {

 	private JLabel _monthLabel;
 	private ArrayList<String> _monthList;
 	private JButton _prior;
 	private JButton _next;
 	private static int begin;
 	private static int _month;
 	@SuppressWarnings("unused")
	private static ArrayList<JLabel> _dateLabel;
    @SuppressWarnings("unused")
	private static ArrayList<LabelListener> _listeners;
    @SuppressWarnings("unused")
	private static ArrayList< ArrayList<LabelListener>> _listenerList;

 	public ButtonListener(JLabel monthLabel, ArrayList<String> monthList, JButton prior, 
 			JButton next, int month, ArrayList<JLabel> dateLabel, ArrayList<LabelListener> listeners, 
 			ArrayList<ArrayList<LabelListener>> listenerList){
 		_monthLabel = monthLabel;
 		_monthList = monthList;
 		_prior = prior;
 		_next = next;
 		_month = month;
 		_dateLabel = dateLabel;
 		_listeners = listeners;
 		_listenerList = listenerList;
 	}
 	
 	@Override
 	public void mouseClicked(MouseEvent e) {
 	}
 	@Override
 	public void mouseEntered(MouseEvent e) {
 	}

 	@Override
 	public void mouseExited(MouseEvent e) {
 	}

 	@Override
 	public void mousePressed(MouseEvent e) throws ArrayIndexOutOfBoundsException, IndexOutOfBoundsException{
 		try{  
 			if(e.getSource() == _prior){
 				if(_month == 1){
 					_monthLabel.setText(_monthList.get(begin - 1));	
 					begin--;	
 					_month = _month - 1;
 					lab9.getDatepanel(_month);
 				}
 				else{
 					lab9.removeListener(_month);
 					_monthLabel.setText(_monthList.get(begin - 1));	
 					begin--;	
 					_month = _month - 1;
 					lab9.getDatepanel(_month);
 				}
 			}
	}
      
 		catch(ArrayIndexOutOfBoundsException ex){
          JOptionPane.showMessageDialog(null, "This is the first month!");
      }
      
 		try{
 			if(e.getSource() == _next){
 				if(_month == 12){
 					_monthLabel.setText(_monthList.get(begin + 1));	
 					begin = begin + 1;
 					_month = _month + 1;
 					lab9.getDatepanel(_month);

 				}
 				else{
 					lab9.removeListener(_month);
 					_monthLabel.setText(_monthList.get(begin + 1));	
 					begin = begin + 1;
 					_month = _month + 1;
 					lab9.getDatepanel(_month);
 				}
 			}
 		}
 		catch(IndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null, "This is the last month!");   
        }    
 	}

 	@Override
 	public void mouseReleased(MouseEvent e) {
 	}
 }


class LabelListener implements MouseListener{
	private  String information = "" ;
	private  int i = 2;
	private static ArrayList<JLabel> _dateLabel;
	public  LabelListener(ArrayList<JLabel> dateLabel){
   	_dateLabel = dateLabel;
   	}
	@Override
	public void mouseClicked(MouseEvent e) throws InputMismatchException {
		if (SwingUtilities.isLeftMouseButton(e)) {
			if(information.equals("")){
				int option =  JOptionPane.showConfirmDialog(null, "No appointment right now, would you like to make a new one now?" );
				if (option == JOptionPane.YES_OPTION){
					boolean continueInput = true;
					do{
						try{
							String Input = "";
							Input =  JOptionPane.showInputDialog(null, "Please enter the appointment information: ");
							if(Input == null){
								return;
							}          	
							else{
  
								if(Input.length() > 0) {
									information = "Appointment 01:   " + Input;
									JOptionPane.showMessageDialog(null, "Information has been stored" + "\n" +"************** Appointment Information *************" +
											"\n" + information );
									continueInput = false;
								} 	
								else {
									throw new InputMismatchException();
								}
							}
						} 	
						catch(InputMismatchException ex){
							JOptionPane.showMessageDialog(null, "Content cannot be empty. Please try again." );
						}   	
					}while(continueInput);	 
				}
				else{
					return;
				}   
 	     	}
			else{    
				int  option =  JOptionPane.showConfirmDialog(null, "You already have  appointment, would you like to make another one?" );
				if (option == JOptionPane.YES_OPTION){
					boolean continueInput1 = true;
					do{
						try{
							String Input =  JOptionPane.showInputDialog(null, "Please enter the appointment information: ");
							if(Input.length() > 0) {	 
								information =   information + "\n" +  "Appointment 0" + i +  ":    " + Input;
								JOptionPane.showMessageDialog(null, "Information has been updated" + "\n" +"************** Appointment Information *************" +
										"\n" + information );
								i++;
								continueInput1 = false;
							}
							else{
								throw new InputMismatchException();
							}
						}
						catch(InputMismatchException ex){
							JOptionPane.showMessageDialog(null, "Content cannot be empty. Please try again." );
						}
					}while(continueInput1);	 
				}
				else{
					return;
				}
			}   	
		}
		if (SwingUtilities.isRightMouseButton(e)) {
			if(!(information.equals(""))){
				JOptionPane.showMessageDialog(null, "************** Appointment Information *************" +
						"\n" + information);	
			}
		}
	}
       

	@Override
	public void mouseEntered(MouseEvent e) {
		for(int i = 0 ; i < 42 ; i ++){
			if(e.getSource() ==	_dateLabel.get(i)){
				_dateLabel.get(i).setBackground(Color.BLACK);

			}
		}
	}
	@Override
	public void mouseExited(MouseEvent e) {
		for(int i = 0 ; i < 42 ; i ++){
			if(e.getSource() ==	_dateLabel.get(i)){
				_dateLabel.get(i).setBackground(Color.WHITE);

			}
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}
}
