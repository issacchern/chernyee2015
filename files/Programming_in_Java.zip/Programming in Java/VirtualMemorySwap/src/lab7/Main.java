package lab7;

import java.util.InputMismatchException;

import javax.swing.JOptionPane;

import lab7.VirtualMemory;

public class Main {
		
	public static void main(String[] args) throws InputMismatchException, NumberFormatException{
		String cmd = "Start";
		
		VirtualMemory virtualMemory = new VirtualMemory();
		while (cmd.compareToIgnoreCase("d") != 0) {
			
            cmd = JOptionPane.showInputDialog(null, "*************** Lab 7 Testing Virtual Memory Menu Options *************"
            		+ "\n'a' - Display Virtual Memory and RAM " + "\n'b' - Retrieve Data"
            		+ "\n'c' - Update Data " + "\n'd' - Exit"
            		+ "\nPlease input a command:" );
            if(cmd == null){
            	return;
            }
            
            if (cmd.compareToIgnoreCase("a") == 0){
            	JOptionPane.showMessageDialog(null, "Output will be displayed in console due to limited space.");
            	virtualMemory.displaySwapPage(); 	
            	
            }   
            
            if (cmd.compareToIgnoreCase("b") == 0){
            	String recordNumber = "";
            	int rafRecordNumber;
            	int intRecordNumber = 0;
    		    double valueFromVirtualMemory;
    		    boolean continueInput = true;
    		    do{
    		    	try{
    		    		recordNumber = JOptionPane.showInputDialog(null, "Please enter a record number: ");
    	    		    intRecordNumber = Integer.parseInt(recordNumber);
    	    		 
    	    		    
    	    		    if(intRecordNumber> 1001 || intRecordNumber < 1){
    	    		    	do{
    	    		    		JOptionPane.showMessageDialog(null, "Input must be within 1 - 1000.");
        	    		    	try{
        	    		    		recordNumber = JOptionPane.showInputDialog(null, "Please enter a record number: ");
        	    		    		intRecordNumber = Integer.parseInt(recordNumber);
        	    		    	}
        	    		    	catch(InputMismatchException ex){
        	    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
        	    		    	}
        	    		    	catch(NumberFormatException ex){
        	    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
        	    		    	}
    	    		    	}while((intRecordNumber> 1001 || intRecordNumber < 1));

    	    		    }
    	    		    continueInput = false;
    		    	}
    		    	catch(InputMismatchException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    	
    		    	catch(NumberFormatException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    }while(continueInput);
    		    
    		    rafRecordNumber = intRecordNumber;
    		    valueFromVirtualMemory = virtualMemory.get(rafRecordNumber);
    		    JOptionPane.showMessageDialog(null, "Random Access File [" + rafRecordNumber + "]: " + valueFromVirtualMemory);
    		    
    		   
            }
            	
            if (cmd.compareToIgnoreCase("c") == 0){
            	String recordNumber = "";
            	int intRecordNumber = 0;
            	String doubleRecordNumber = "";
            	int rafRecordNumber;
    		    Double newValueFromVirtualMemory = 0.0;
    		    boolean continueInput = true;
    		    do{
    		    	try{
    		    		recordNumber = JOptionPane.showInputDialog(null, "Please enter a record number: ");
    	    		    intRecordNumber = Integer.parseInt(recordNumber);
    	    		    if(intRecordNumber> 1001 || intRecordNumber < 1){
    	    		    	do{
    	    		    		JOptionPane.showMessageDialog(null, "Input must be within 1 - 1000.");
        	    		    	try{
        	    		    		recordNumber = JOptionPane.showInputDialog(null, "Please enter a record number: ");
        	    		    		intRecordNumber = Integer.parseInt(recordNumber);
        	    		    	}
        	    		    	catch(InputMismatchException ex){
        	    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
        	    		    	}
        	    		    	catch(NumberFormatException ex){
        	    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
        	    		    	}
        	    		    	
    	    		    	}while((intRecordNumber> 1001 || intRecordNumber < 1));

    	    		    }
    	    		    continueInput = false;
    		    	}
    		    	catch(InputMismatchException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    	
    		    	catch(NumberFormatException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    }while(continueInput);
    		    
    		    rafRecordNumber = intRecordNumber;
    		    
    		    boolean continueInput2 = true;
    		    do{
    		    	try{
    		    		doubleRecordNumber = JOptionPane.showInputDialog(null, "Please input a value: ");
    	    		    newValueFromVirtualMemory = Double.parseDouble(doubleRecordNumber);
    	    		    continueInput2 = false;
    		    	}
    		    	
    		    	catch(InputMismatchException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    	
    		    	catch(NumberFormatException ex){
    		    		JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
    		    	}
    		    }while(continueInput2);
    		   
    		    virtualMemory.put(rafRecordNumber, newValueFromVirtualMemory);
    		    JOptionPane.showMessageDialog(null, "Random Access File [" + rafRecordNumber + "]: " + newValueFromVirtualMemory);
            }
            
		}
	}


}
