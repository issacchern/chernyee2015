package lab7;

import java.io.*;


public class RandomAccess{
	public static final String RA_FILE_NAME = "RandomAccessFile";
	public static final int MAX_NUMBER_OF_RECORDS = 1000;    
	public static final int MANDATORY_ID_LENGTH = 4;
	public static final int MANDATORY_DOUBLE_LENGTH = 10;
	public static final int INFO_DATA_LENGTH = MANDATORY_ID_LENGTH + MANDATORY_DOUBLE_LENGTH;
	public static final int RAF_EXTRA_DATA  = 2;
	public static final int RAF_DATA_LENGTH = RAF_EXTRA_DATA + INFO_DATA_LENGTH;
	public static final String INFO_DATA_RECORD = "9999" + "9999999.99";
	public static final String RAF_DATA_RECORD = "12" + INFO_DATA_RECORD;

	private RandomAccess(){}

	public static RandomAccessFile createRandomAccessFile(String raFileName){
		RandomAccessFile raFile = null;
		String rafRecordToWrite;
		try{
			raFile = new RandomAccessFile(raFileName, "rw");
		}
		catch (FileNotFoundException ex){
			System.out.println("File: >" + raFileName + "< not found!");
		}
		
		for (int i = 0; i < MAX_NUMBER_OF_RECORDS; i++){
			rafRecordToWrite = String.format("%4s%10.2f", i, (double)(i+1));
			try{
				raFile.writeUTF(rafRecordToWrite);
			}
			catch (IOException e){
				System.out.println("Unable to write to file >" + raFileName + "< not found!");
			}
		}
		return raFile;
	}

	public static void updateRecordToRandomAccessFile( RandomAccessFile raFile, int recordNumber, String infoData, String testLocation){
		try{
			raFile.seek(RAF_DATA_LENGTH * (recordNumber - 1));
		}
		catch ( IOException e ){
			if ( testLocation.length() > 0 )
				testLocation = testLocation + " -- ";
			System.out.println( testLocation + "Unable to find record: >" + recordNumber + "<");
		}
		try{
			raFile.writeUTF(infoData);
		}
		catch (IOException ex){		
			System.out.println("Unable to update record: >" + recordNumber + "< not found!");

		}
	}

	public static double retrieveDoubleFromRecord(RandomAccessFile raFile, int recordNumber){
		String recordInfoData = "";
		double doubleInfo = 0.0;
        recordInfoData = retrieveOldRecord( raFile, recordNumber );
		try{
			doubleInfo = Double.parseDouble( recordInfoData.substring( MANDATORY_ID_LENGTH ) );;
		}
		catch ( NumberFormatException e ){													
			System.out.println( "        Current RAF record info: " + recordInfoData );
			System.out.println("Unable to convert to double: >" + recordNumber + "<");
		}
		return doubleInfo;
	}

	public static String retrieveOldRecord(RandomAccessFile raFile, int recordNumber){
		String recordData = "";
		try{
			raFile.seek(RAF_DATA_LENGTH * (recordNumber - 1));
		}
		catch (IOException ex){			
			System.out.println("Unable to find record: >" + recordNumber + "<");
		}
		
		try{
			recordData = raFile.readUTF();
		}
		catch (IOException ex){			
			System.out.println("Unable to update record: >" + recordNumber + "<");
		}
		return recordData;
	}

	public static String createRecordData( double infoDouble ){
		String strInfoDouble = "";
		strInfoDouble = String.format( "%" + MANDATORY_DOUBLE_LENGTH + "s", infoDouble );
		return strInfoDouble;
	}
}
