package lab7;

import java.io.*;

public class VirtualMemory {
	  public static final int DEFAULT_RAM_CAPACITY = 100;
	  public static final int DEFAULT_VIRTUALMEMORY_CAPACITY = 1000;
	  private double RAMArray[];
	  private RandomAccessFile raFile;
	  private int currentSwapPageInMemory;
	  
	  public void displaySwapPage() {
		  System.out.println("");
		    System.out.println( "    ---- Current Virtual Memory and RAM ----\n" );
		    for (int i = 0; i < RAMArray.length; i++) {
		    	int rafRecordNumber = ((currentSwapPageInMemory - 1) * RAMArray.length ) + 1 + i;
		        System.out.println( " Virtual Memory [ " + rafRecordNumber + " ] ------ RAM [ " + i + " ]: " + RAMArray[i]);	    	
		    }
	  }

	  public VirtualMemory() {
		    RAMArray = new double[DEFAULT_RAM_CAPACITY];
		    initializeSwapMemory();
	  }
	  
	  

	  private void initializeSwapMemory() {
		  
		    int startAtRAFrecord = 1;
		    raFile = createVMRandomAccessFile();
		    updateSwapPageFromRAF(startAtRAFrecord);
	  }
	  
	  private RandomAccessFile createVMRandomAccessFile() {
		    RandomAccessFile raFile = null;
		    raFile = RandomAccess.createRandomAccessFile(RandomAccess.RA_FILE_NAME);
		    return raFile;
	  }
	  
	  private void updateSwapPageFromRAF(int beginRAF) {
		    int endRAF = beginRAF + (RAMArray.length - 1);
		    int swapPageIndex = 0;
		    double doubleValue;

		    for (int recordNumber = beginRAF; recordNumber <= endRAF; recordNumber++) {
			      doubleValue = RandomAccess.retrieveDoubleFromRecord(raFile, recordNumber);
			      RAMArray[swapPageIndex] = doubleValue;
			      swapPageIndex++;
		    }
		    
		    currentSwapPageInMemory = calculatePageNumber( beginRAF );
	  }

   
	  public double get(int rafRecordNumber) {
		    double valueFromSwap;
		    int swapPageIndex;
		    
		    try {
			      swapPageIndex = rafRecordNumber - 1;
			      valueFromSwap = RAMArray[swapPageIndex];
		    }
		    catch (ArrayIndexOutOfBoundsException ex) {
			      handleVirtualMemoryArrayIndexOutOfBounds(rafRecordNumber);
			      swapPageIndex = calculatePageOffset(rafRecordNumber);
			      valueFromSwap = RAMArray[swapPageIndex];
		    }     
		    return valueFromSwap;
	  }
	  
	  private void handleVirtualMemoryArrayIndexOutOfBounds(int rafRecordNumberCausedException) {
		    int startAtRAFrecord;
		    startAtRAFrecord = ((currentSwapPageInMemory - 1) * RAMArray.length ) + 1;    
		    updateRandomAccessFileFromSwapPage(startAtRAFrecord); 
		    startAtRAFrecord = ((calculatePageNumber(rafRecordNumberCausedException)- 1) * RAMArray.length) + 1;   
		    updateSwapPageFromRAF(startAtRAFrecord); 
	  }   
	  
	  public void put(int rafRecordNumber, double newValue) {	  
		    int swapPageIndex;
		    try {
			      swapPageIndex = rafRecordNumber - 1;
			      RAMArray[swapPageIndex] = newValue;
		    }

		    catch (ArrayIndexOutOfBoundsException e){
			      handleVirtualMemoryArrayIndexOutOfBounds(rafRecordNumber);
			      swapPageIndex = calculatePageOffset(rafRecordNumber);
			      RAMArray[swapPageIndex] = newValue;
		    }   
		    
	  }


	  private int calculatePageNumber(int rafRecordNumber) {
		    int pageNumber;
		    pageNumber = ((rafRecordNumber - 1) / RAMArray.length) + 1;
		    return pageNumber;
	  }

	  private int calculatePageOffset(int rafRecordNumber) {
		    int swapPageOffset;
		    swapPageOffset = ((rafRecordNumber - 1) % RAMArray.length);
		    return swapPageOffset;
	  }

	  private void updateRandomAccessFileFromSwapPage(int rafRecordNumber) {
		    int beginRAF = rafRecordNumber;
		    int endRAF = beginRAF + (RAMArray.length - 1);
		    int swapPageIndex = 0;
		    String infoRecord = "";
		    for (int recordNumber = beginRAF; recordNumber <= endRAF; recordNumber++) {
			      infoRecord = RandomAccess.createRecordData( RAMArray[swapPageIndex] );
			      RandomAccess.updateRecordToRandomAccessFile( raFile, recordNumber, infoRecord, "Virtual Manager" );
			      swapPageIndex++;
		    }
	  }   
	   
	  

}
